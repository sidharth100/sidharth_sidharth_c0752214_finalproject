import java.util.Arrays;
import java.util.Scanner;

public class AirlineSystem
{
       static Boolean seat[] = new Boolean[10] ;


    public static void print()
    {
        System.out.println("Welcome to Airline Reservation System");
        System.out.println("Type 1 for First Class seat ");
        System.out.println("Type 2 for Economy Class seat");
    }

    public static void boardingPass(int snum,String s )
    {
        System.out.println("Seat Number: " +snum+"\n"+"Class Type: " +s);
    }


    public static void firstClass()
    {
        int count = 0;
        for (int i = 0 ; i < 5 ; i++) {
            if (seat[i]==Boolean.TRUE)
            {
                count++;
            }
            else
            {
                System.out.println("FirstClass Seat is available");
                System.out.println("Press 1 to Confirm");
                Scanner scr = new Scanner(System.in);
                int num = scr.nextInt();
                if (num == 1)
                {
                    seat[i] = true;
                    System.out.println("Seat confirmed");
                    boardingPass(i+1,"FirstClass");
                    break;
                }
                else
                {
                    System.out.println("Please choose the right option");
                }
            }
        }
        if(count == 5)
        {
            System.out.println("This Class is full \n If you want to book Economy class press 2 : ");
            Scanner scr = new Scanner(System.in);
            int num2 =scr.nextInt();
            if(num2 == 2)
            {
                economyClass();
            }
        }
    }



    public static void economyClass()
            {

                int count = 0;
                for (int i = 5 ; i < 10 ; i++) {
                    if (seat[i]==Boolean.TRUE)
                    {
                        count++;
                    }
                    else
                    {
                        System.out.println("EconomyClass Seat is available");
                        System.out.println("Press 2 to Confirm");
                        Scanner scr = new Scanner(System.in);
                        int num = scr.nextInt();
                        if (num == 2)
                        {
                            seat[i] = true;
                            System.out.println("Seat confirmed");
                            boardingPass(i+1,"EconomyClass");
                            break;
                        }
                        else
                        {
                            System.out.println("Please choose the right option");
                        }
                    }
                }
                if(count == 10)
                {
                    System.out.println("This Class is full \n If you want to book First class press 1 : ");
                    Scanner scr = new Scanner(System.in);
                    int num2 =scr.nextInt();
                    if(num2 == 2)
                    {
                        firstClass();
                    }
                }
            }




    public static void main(String args[])
    {
        print();
        Scanner s = new Scanner(System.in);
        int a = s.nextInt();

        if (a == 1)
        {
            firstClass();
        }
        else if(a == 2)
        {
            economyClass();
        }
        else
        {
            System.out.println("Please choose the right option ");
        }

        for(int i=0;i<10;i++) {
            System.out.println("If you want to continue press 1");
            int b = s.nextInt();

            if (b == 1)
            {
                firstClass();
            }
            else if(b == 2)
            {
                economyClass();
            }
            else
            {
                System.out.println("Please choose the right option ");
            }
        }
    }
}
